export class Pizza {
    pizzaName:string='';
    pizzaType:string='';
    pizzaSize:string='';
    pizzaPrice:string='';
    description:string='';
}
